import json, math, os

OUT = 'courses'
os.makedirs(OUT, exist_ok=True)

def ell(t, name, x, y, rx, ry, pen=0, rot=0):
    return {"type": t, "name": name, "shape": "ellipse", "center": [x, y],
            "radiusYd": [rx, ry], "rotationDeg": rot, "penaltyStrokes": pen}

def bunker(name, x, y, rx, ry, rot=0): return ell("bunker", name, x, y, rx, ry, 0, rot)
def water(name, x, y, rx, ry, rot=0):  return ell("water",  name, x, y, rx, ry, 1, rot)
def waste(name, x, y, rx, ry, rot=0):  return ell("waste",  name, x, y, rx, ry, 0, rot)
def ob(side, a, b):  return {"type":"ob","side":side,"fromYd":a,"toYd":b,"penaltyStrokes":1}

def centerline(yards, bends):
    """bends: list of (frac_downrange, lateral_yd). Always starts at tee [0,0]."""
    pts = [[0,0]]
    for f, lat in bends:
        pts.append([round(lat), round(yards*f)])
    pts.append([round(bends[-1][1]) if bends else 0, yards])
    return pts

def elev(yards, profile):
    """profile: list of (frac, feet)."""
    return [[round(yards*f), ft] for f, ft in profile]

def mk(n, par, hcp, tips, tee_pcts, bends, prof, fw, rough, hz, green, pin_off, notes, scenery):
    tees = [{"name": nm, "yards": round(tips*p)} for nm, p in tee_pcts]
    cl = centerline(tips, bends)
    end = cl[-1]
    return {
        "number": n, "par": par, "handicap": hcp,
        "tees": tees,
        "centerline": cl,
        "elevationFt": elev(tips, prof),
        "widthYd": {"fairway": fw, "rough": rough},
        "hazards": hz,
        "green": {"center": end, "radiusYd": green[0], "tiers": green[1], "slopePct": green[2]},
        "pin": [end[0] + pin_off[0], end[1] + pin_off[1]],
        "designNotes": notes,
        "scenery": scenery,
    }

def build(meta, holes):
    course = dict(meta)
    course["par"] = sum(h["par"] for h in holes)
    course["holes"] = len(holes)
    tee_names = [t["name"] for t in holes[0]["tees"]]
    course["tees"] = [
        {"name": nm,
         "yards": sum(h["tees"][i]["yards"] for h in holes),
         "rating": meta["_ratings"][i], "slope": meta["_slopes"][i]}
        for i, nm in enumerate(tee_names)
    ]
    del course["_ratings"]; del course["_slopes"]
    course["holesData"] = holes
    return course

def validate(c):
    e = []
    hs = c["holesData"]
    n = len(hs)
    for h in hs:
        y = h["tees"][0]["yards"]; p = h["par"]
        if p == 3 and not 100 <= y <= 260: e.append(f"h{h['number']} par3 {y}yd")
        if p == 4 and not 280 <= y <= 520: e.append(f"h{h['number']} par4 {y}yd")
        if p == 5 and not 460 <= y <= 660: e.append(f"h{h['number']} par5 {y}yd")
        ys = [t["yards"] for t in h["tees"]]
        if ys != sorted(ys, reverse=True): e.append(f"h{h['number']} tees not descending")
        if abs(h["centerline"][-1][1] - y) > 25: e.append(f"h{h['number']} centerline/yardage mismatch")
        gx, gy = h["green"]["center"]; px, py = h["pin"]
        if math.dist((gx,gy),(px,py)) > h["green"]["radiusYd"]: e.append(f"h{h['number']} pin outside green")
    hcps = sorted(h["handicap"] for h in hs)
    want = list(range(1, 2*n, 2)) if n == 9 else list(range(1, n+1))
    if hcps != want: e.append(f"handicaps {hcps} != {want}")
    if c["par"] != sum(h["par"] for h in hs): e.append("par mismatch")
    return e
