from gen import *
import math

TEE=[("Tips",1.0),("Championship",0.94),("Members",0.87),("Forward",0.74)]
V={
 "theme":"lowcountry-marsh",
 "palette":{"fairway":"#4f8a41","rough":"#6a8a4c","sand":"#d9c9a4","waste":"#b7a986",
            "water":"#3a6f66","sky":"#b8d4de","canvas":"#e9e4d2"},
 "terrain":{"base":"tidal-marsh","fairwayTexture":"bermuda-stripe","roughTexture":"marsh-fescue",
            "reliefFt":[-6,18],"exaggeration":1.6,
            "note":"Dead flat lowcountry; the drama is water, live oaks and angles, never elevation."},
 "vegetation":[
   {"species":"live-oak","density":"heavy","band":"rough-edge","heightFt":[38,62]},
   {"species":"palmetto","density":"medium","band":"hole-corridor","heightFt":[12,20]},
   {"species":"loblolly-pine","density":"medium","band":"rough-edge","heightFt":[46,72]}],
 "features":["brackish lagoons","spartina marsh edges","oyster-shell waste",
             "live-oak corridors","red-and-white lighthouse finish"],
 "sky":{"timeOfDay":"morning","cloud":"humid-haze","hazeKm":14},
 "water":{"style":"still-brackish","reflectivity":0.75,"waveHeightFt":[0,1],"surfLine":False},
}
def lagoon(name,x,y,rx,ry): return water(name,x,y,rx,ry)
def marsh(name,x,y,rx,ry):  return waste(name,x,y,rx,ry)

H=[
 mk(1,4,11,415,TEE,[(.5,14),(.85,24)],[(0,0),(1,2)],40,64,
    [marsh("right spartina",34,240,14,40),bunker("left fairway",-26,272,10,14),bunker("greenside",12,406,7,9)],
    (17,1,2.0),(3,4),"Gentle opener bending past the first lagoon, live oaks framing both sides.",
    {"backdrop":"oak-corridor","features":["marsh-edge"]}),
 mk(2,4,5,452,TEE,[(.45,-16),(.82,-30)],[(0,0),(1,4)],36,58,
    [lagoon("left lagoon",-42,300,20,44),bunker("right shoulder",28,300,10,14),bunker("greenside right",14,444,8,10)],
    (16,1,2.2),(-3,4),"The lagoon runs the whole left side of the dogleg; the safe line leaves a long iron.",
    {"backdrop":"lagoon","features":["water-left"]}),
 mk(3,3,15,172,TEE,[(.5,0)],[(0,0),(1,0)],0,52,
    [lagoon("fronting marsh",0,96,26,30),bunker("back left",-12,182,7,9)],
    (15,1,2.4),(4,-3),"All carry over the marsh to a green sitting on oyster-shell banks.",
    {"backdrop":"open-marsh","features":["forced-carry"]}),
 mk(4,5,7,548,TEE,[(.32,16),(.62,34),(.88,18)],[(0,0),(1,2)],38,60,
    [marsh("right marsh",36,320,16,48),lagoon("lay-up pond",-24,420,14,20),bunker("greenside",10,540,8,10)],
    (18,2,2.0),(3,5),"Three shots along the tidal creek unless the second carries the lay-up pond.",
    {"backdrop":"tidal-creek","features":["risk-reward"]}),
 mk(5,4,1,468,TEE,[(.46,-14),(.84,-26)],[(0,0),(1,3)],34,56,
    [marsh("left marsh",-36,260,14,50),bunker("right pair a",30,310,9,12),bunker("right pair b",26,340,8,11),
     bunker("greenside left",-12,460,8,10)],
    (14,1,2.8),(-3,4),"Number one on the card: narrow, oaks pressing in, marsh waiting left the whole way.",
    {"backdrop":"oak-corridor","features":["narrow"]}),
 mk(6,4,13,392,TEE,[(.5,18),(.86,30)],[(0,0),(1,0)],42,66,
    [bunker("corner",24,236,11,15),marsh("right spartina",38,330,12,32),bunker("greenside",14,384,7,9)],
    (16,1,2.2),(3,4),"Shortish two-shotter around a single sprawling corner bunker.",
    {"backdrop":"open-marsh","features":["strategic-corner"]}),
 mk(7,3,17,152,TEE,[(.5,0)],[(0,0),(1,0)],0,50,
    [bunker("ring left",-14,146,8,10),bunker("ring right",15,150,8,10),bunker("ring back",0,170,8,9)],
    (13,1,3.0),(-3,3),"A wedge, but the smallest green on the property, ringed by sand.",
    {"backdrop":"oak-corridor","features":["tiny-green"]}),
 mk(8,4,3,455,TEE,[(.44,15),(.8,28)],[(0,0),(1,2)],36,58,
    [lagoon("carry lagoon",8,120,22,34),marsh("right marsh",36,340,14,40),bunker("greenside left",-13,448,8,10)],
    (15,1,2.6),(3,-4),"Tee shot carries the lagoon corner; the more you bite off, the shorter the approach.",
    {"backdrop":"lagoon","features":["cape-tee"]}),
 mk(9,5,9,540,TEE,[(.3,-14),(.6,-30),(.88,-16)],[(0,0),(1,2)],38,62,
    [marsh("left marsh",-38,300,16,52),bunker("lay-up pair a",22,400,9,12),bunker("lay-up pair b",18,432,8,11),
     bunker("greenside",-10,532,8,10)],
    (17,2,2.0),(-3,5),"Out to the turn past the shrimp docks, marsh left from tee to green.",
    {"backdrop":"tidal-creek","features":["marsh-edge"]}),
 mk(10,4,8,428,TEE,[(.5,16),(.85,26)],[(0,0),(1,0)],38,62,
    [bunker("left fairway",-28,280,10,14),marsh("right marsh",36,350,14,36),bunker("greenside right",13,420,8,10)],
    (16,1,2.4),(3,4),"Back nine opens under the biggest live oak on the course.",
    {"backdrop":"oak-corridor","features":["specimen-oak"]}),
 mk(11,3,18,188,TEE,[(.5,0)],[(0,0),(1,0)],0,52,
    [lagoon("right lagoon",26,110,18,34),bunker("front left",-13,178,8,10)],
    (16,1,2.2),(4,3),"Mid-iron with the lagoon glittering right and nothing but green to aim at.",
    {"backdrop":"lagoon","features":["water-right"]}),
 mk(12,4,4,462,TEE,[(.45,-15),(.83,-28)],[(0,0),(1,3)],34,58,
    [marsh("left marsh",-36,280,16,46),bunker("right shoulder",28,320,10,13),bunker("greenside",12,454,8,10)],
    (15,1,2.8),(-3,4),"Long and bending left, the green benched just above the high-tide line.",
    {"backdrop":"tidal-creek","features":["narrow"]}),
 mk(13,4,14,398,TEE,[(.5,14),(.86,22)],[(0,0),(1,0)],40,64,
    [bunker("centerline",0,262,10,13),marsh("right spartina",36,330,12,32),bunker("greenside left",-12,390,7,9)],
    (17,1,2.0),(3,4),"A centreline bunker splits the fairway — choose a side from the tee.",
    {"backdrop":"open-marsh","features":["split-decision"]}),
 mk(14,5,10,552,TEE,[(.3,16),(.62,36),(.88,20)],[(0,0),(1,2)],38,60,
    [lagoon("second-shot lagoon",-26,380,18,26),marsh("right marsh",38,300,14,44),bunker("greenside",11,544,8,10)],
    (18,2,2.0),(3,5),"The lagoon pinches the lay-up to a ribbon; the brave carry it at the narrows.",
    {"backdrop":"lagoon","features":["risk-reward"]}),
 mk(15,3,16,208,TEE,[(.5,0)],[(0,0),(1,0)],0,54,
    [marsh("fronting marsh",0,120,28,36),bunker("back right",14,218,8,9)],
    (17,1,2.2),(-4,3),"Longest of the one-shotters, across open marsh with the wind off the sound.",
    {"backdrop":"open-marsh","features":["forced-carry","wind-exposed"]}),
 mk(16,4,6,448,TEE,[(.46,-16),(.84,-28)],[(0,0),(1,2)],36,58,
    [marsh("left marsh",-36,280,14,44),bunker("right pair a",30,300,9,12),bunker("right pair b",26,332,8,11),
     bunker("greenside right",13,440,8,10)],
    (15,1,2.6),(-3,4),"The corridor narrows with every yard; par here gains a shot on the field.",
    {"backdrop":"oak-corridor","features":["narrow"]}),
 mk(17,4,12,418,TEE,[(.5,15),(.85,26)],[(0,0),(1,0)],38,62,
    [lagoon("right lagoon",34,300,20,40),bunker("left fairway",-26,290,10,13),bunker("greenside left",-12,410,8,10)],
    (16,1,2.4),(3,4),"Water right on the drive, water right on the approach — a lighthouse hole in waiting.",
    {"backdrop":"lagoon","features":["water-right"]}),
 mk(18,4,2,472,TEE,[(.44,14),(.82,26)],[(0,0),(1,2)],36,60,
    [lagoon("sound edge",-44,340,24,60),bunker("right shoulder",30,340,10,13),bunker("greenside",12,464,9,11)],
    (17,1,2.6),(3,4),"Home along the open sound to the striped lighthouse — the calmest-looking, hardest-playing finish.",
    {"backdrop":"lighthouse-sound","features":["grandstand-finish","water-left"]}),
]

meta={"id":"palmetto-sound","name":"Palmetto Sound","fictional":True,
 "designer":"TeeReady original — lowcountry strategic","style":"lowcountry marsh",
 "location":{"fictional":True,"setting":"Sea-island marshes behind a wide tidal sound"},
 "defaultWind":{"speedMph":9,"fromDeg":140},
 "surface":{"fairwayFirmness":"medium","greenSpeedStimp":11.5,"altitudeFt":8},
 "visual":V,"_ratings":[75.9,73.8,71.2,67.6],"_slopes":[147,141,133,122]}

CHAR={1:'classic',2:'broad-rolling',3:'wide-open',4:'broad-rolling',5:'narrow-long',6:'classic',
      7:'tight',8:'broad-rolling',9:'classic',10:'classic',11:'wide-open',12:'narrow-long',
      13:'classic',14:'broad-rolling',15:'wide-open',16:'narrow-long',17:'classic',18:'broad-rolling'}

def finish(c, fname, label):
    for h in c['holesData']:
        h['character']=CHAR.get(h['number'],'classic')
        yds=h['tees'][0]['yards']; n=h['number']; fw=h['widthYd']['fairway']
        # the same gentle organic wiggle the other courses carry
        A=min(0.5*max(fw,26), 7+yds/55); P=170+(n*37%120); ph=(n*2.399)%6.283
        def interp(pts,y):
            if y<=pts[0][1]: return pts[0][0]
            for i in range(1,len(pts)):
                if y<=pts[i][1]:
                    t=(y-pts[i-1][1])/max(1e-6,pts[i][1]-pts[i-1][1]); sm=t*t*(3-2*t)
                    return pts[i-1][0]+(pts[i][0]-pts[i-1][0])*sm
            return pts[-1][0]
        base=h['centerline']
        def wig(y):
            w=math.sin(math.pi*min(1,max(0,y/yds)))**0.8
            return interp(base,y)+A*math.sin(2*math.pi*y/P+ph)*w
        pts=[[round(wig(y),1),y] for y in list(range(0,yds,24))]+[[round(wig(yds),1),yds]]
        for z in h['hazards']:
            if z.get('center'):
                yz=z['center'][1]; z['center'][0]=round(z['center'][0]+(wig(yz)-interp(base,yz)),1)
        h['centerline']=pts
        g=h['green']; g['center']=[pts[-1][0],yds]
        r=g['radiusYd']; inset=r*0.55; cx,cy=g['center']; tiers=g.get('tiers',1)
        g['pinZones']=[
          {"id":"front","x":round(cx-inset*0.35,1),"y":round(cy-inset,1),"difficulty":1,
           "note":"Front — the safe morning pin."},
          {"id":"middle","x":round(cx+inset*0.25,1),"y":round(cy,1),"difficulty":2,
           "note":"Middle — the everyday pin."},
          {"id":"back","x":round(cx-inset*0.15,1),"y":round(cy+inset,1),"difficulty":3,
           "note":("Back tier, tucked" if tiers>1 else "Back edge, tucked")+" — two clubs more than it looks."}]
        g['defaultPin']="middle"
        h['pin']=[g['pinZones'][1]['x'],g['pinZones'][1]['y']]
    errs=validate(c)
    json.dump(c,open(f'{OUT}/{fname}.json','w'),indent=2)
    print(label,"— par",c['par'],"|",c['tees'][0]['yards'],"yd | slope",c['tees'][0]['slope'])
    print("validation:","PASS" if not errs else errs)

if __name__=='__main__':
    finish(build(meta,H),'palmetto-sound','Palmetto Sound')
