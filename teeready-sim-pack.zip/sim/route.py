import json, math

def dirv(deg):
    r=math.radians(deg); return (math.sin(r), math.cos(r))   # world (E, N), 0deg = north

# Heading sequences per routing archetype (from the inspiration maps)
PLANS = {
 'lantern-point': dict(pattern='coastal-arc',   # Pebble: out along the coast, back inland
   head=[60,35,70,45,25,55,30,65,40, 230,255,220,250,235,260,225,245,215],
   shift={9:(90,110)}),                          # after 9: 110yd left — back nine runs inland
 'cedar-hollow': dict(pattern='parkland-loop',  # Pebble interior: one returning loop
   head=[10,55,100,145,190,235,280,325,355], shift={}),
 'granite-ridge': dict(pattern='ridge-scatter', # French Lick: sticks at wild angles
   head=[30,115,55,150,80,5,120,45,95, 210,285,235,320,255,200,300,230,270], shift={}),
 'coral-key': dict(pattern='lake-loops',        # Bay Hill: loops around water
   head=[95,50,5,320,275,230,185,140,110], shift={}),
 'driftwater-straits': dict(pattern='shore-strip', # Whistling: out-and-back on a strip
   head=[8,354,12,2,350,6,14,356,4, 186,178,192,184,176,190,182,188,180],
   shift={9:(90,85)}),
 'palmetto-sound': dict(pattern='marsh-loops',    # Harbour Town: loops threading the lagoons
   head=[120,65,20,335,280,225,180,135,90, 45,0,315,270,225,170,115,70,25], shift={}),
 'vermilion-mesa': dict(pattern='canyon-scatter', # target golf: sticks at wild angles off the mesa
   head=[40,130,75,165,100,25,140,60,110, 220,300,250,335,270,205,315,240,285], shift={}),
 'north-gale-links': dict(pattern='out-and-back', # classic links strip along the shore
   head=[22,10,28,16,4,24,12,30,18, 198,206,192,202,214,196,208,190,200],
   shift={9:(90,70)}),
}

def route(course):
    plan=PLANS[course['id']]; heads=plan['head']; shifts=plan['shift']
    tee=(0.0,0.0); out=[]
    for i,h in enumerate(course['holesData']):
        th=heads[i]
        if i in shifts:
            a,dist=shifts[i]; lx=dirv((heads[i]+a)%360)
            tee=(tee[0]+lx[0]*dist, tee[1]+lx[1]*dist)
        d=dirv(th); r=dirv((th+90)%360)
        end=h['centerline'][-1]
        green=(tee[0]+d[0]*end[1]+r[0]*end[0], tee[1]+d[1]*end[1]+r[1]*end[0])
        out.append(dict(n=h['number'], tee=[round(tee[0],1),round(tee[1],1)], headingDeg=th))
        gap=35
        nd=dirv(heads[(i+1)%len(heads)])
        tee=(green[0]+nd[0]*gap, green[1]+nd[1]*gap)
    course['routing']=dict(pattern=plan['pattern'], holes=out)
    return course

for cid in PLANS:
    p=f'courses/{cid}.json'
    c=json.load(open(p)); c=route(c); json.dump(c,open(p,'w'),indent=2)
    xs=[]; ys=[]
    for rh,h in zip(c['routing']['holes'],c['holesData']):
        t=rh['tee']; th=rh['headingDeg']; d=dirv(th); r=dirv((th+90)%360); e=h['centerline'][-1]
        xs+= [t[0], t[0]+d[0]*e[1]+r[0]*e[0]]; ys+=[t[1], t[1]+d[1]*e[1]+r[1]*e[0]]
    print(f"{c['name']:22} {c['routing']['pattern']:14} property {round(max(xs)-min(xs))}x{round(max(ys)-min(ys))} yd")
