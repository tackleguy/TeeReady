#!/usr/bin/env node
/** Course validator. Rejects, never warns — a bad course surfaces as weird scoring three holes in. */
import { readFileSync, readdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const DIR = process.argv[2] || join(dirname(fileURLToPath(import.meta.url)), '../src/data/courses');
const PAR_YD = { 3: [100, 260], 4: [280, 520], 5: [460, 660] };
const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);

function check(c) {
  const e = [];
  const hs = c.holesData, n = hs.length;
  if (c.fictional !== true) e.push('fictional must be true — never present a design as a real course');
  if (c.par !== hs.reduce((s, h) => s + h.par, 0)) e.push('course par != sum of hole pars');
  for (const h of hs) {
    const y = h.tees[0].yards, band = PAR_YD[h.par];
    if (!band) e.push(`h${h.number} par ${h.par} not 3/4/5`);
    else if (y < band[0] || y > band[1]) e.push(`h${h.number} par${h.par} ${y}yd outside ${band.join('-')}`);
    const ys = h.tees.map((t) => t.yards);
    if (ys.join() !== [...ys].sort((a, b) => b - a).join()) e.push(`h${h.number} tees not descending`);
    if (Math.abs(h.centerline.at(-1)[1] - y) > 25) e.push(`h${h.number} centerline/yardage mismatch`);
    if (dist(h.green.center, h.pin) > h.green.radiusYd) e.push(`h${h.number} pin outside green`);
    for (const hz of h.hazards ?? []) {
      if (hz.type !== 'ob' && hz.center && hz.center[1] < 40) e.push(`h${h.number} hazard "${hz.name}" overlaps the tee`);
    }
  }
  const hcps = hs.map((h) => h.handicap).sort((a, b) => a - b);
  const want = n === 9 ? Array.from({ length: 9 }, (_, i) => i * 2 + 1) : Array.from({ length: n }, (_, i) => i + 1);
  if (hcps.join() !== want.join()) e.push(`handicaps ${hcps.join(',')} should be ${want.join(',')}`);
  return e;
}

let bad = 0;
for (const f of readdirSync(DIR).filter((f) => f.endsWith('.json'))) {
  const c = JSON.parse(readFileSync(join(DIR, f), 'utf8'));
  const e = check(c);
  const t = c.tees[0];
  if (e.length) { bad++; console.error(`✗ ${c.name}`); e.forEach((x) => console.error(`    ${x}`)); }
  else console.log(`✓ ${c.name.padEnd(20)} par ${c.par} · ${t.yards} yd · slope ${t.slope} · ${c.holes} holes`);
}
console.log(`\n${bad ? `${bad} invalid` : 'all courses valid'}`);
process.exit(bad ? 1 : 0);
